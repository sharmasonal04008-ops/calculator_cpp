#include<iostream>
using namespace std;

int main()
{
    double n1, n2;
    char op;

    cout << "n1: ";
    cin >> n1;

    cout << "+, -, *, /, %" << endl;
    cin >> op;

    cout << "n2: ";
    cin >> n2;

    if (op == '+')
        cout << n1 + n2 << endl;
    else if (op == '-')
        cout << n1 - n2 << endl;
    else if (op == '*')
        cout << n1 * n2 << endl;
    else if (op == '/') {
        if (n2 == 0)
            cout << "Error: cannot divide by zero!" << endl;
        else
            cout << n1 / n2 << endl;
    }
    else if (op == '%') {
        if (n2 == 0)
            cout << "Error: cannot divide by zero!" << endl;
        else
            cout << fmod(n1, n2) << endl;
    }
    else
        cout << "Invalid operator!" << endl;

    return 0;
}
